<?php
// Biar URL /admin.php tetap hidup, arahkan ke /dashboard
header('Location: /dashboard');
exit;
