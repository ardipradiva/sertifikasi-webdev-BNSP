<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  
  <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="card p-5">
      <div class="text-xs font-semibold text-brand-500 uppercase">Earnings (Monthly)</div>
      <div class="mt-1 text-3xl font-bold">Rp <?php echo e(number_format($earnMonthly,0,',','.')); ?></div>
    </div>
    <div class="card p-5">
      <div class="text-xs font-semibold text-brand-500 uppercase">Earnings (Annual)</div>
      <div class="mt-1 text-3xl font-bold">Rp <?php echo e(number_format($earnAnnual,0,',','.')); ?></div>
    </div>
    <div class="card p-5">
      <div class="text-xs font-semibold text-brand-500 uppercase">Tasks</div>
      <div class="mt-1 text-3xl font-bold"><?php echo e($tasksPct); ?>%</div>
      <div class="mt-2 h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
        <div class="h-full bg-brand-500" style="width: <?php echo e($tasksPct); ?>%"></div>
      </div>
    </div>
    <div class="card p-5">
      <div class="text-xs font-semibold text-brand-500 uppercase">Pending Requests</div>
      <div class="mt-1 text-3xl font-bold"><?php echo e($pendingReq); ?></div>
    </div>
  </div>

  
  <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
    <div class="card p-5">
      <div class="text-slate-500 text-sm">Total Products</div>
      <div class="mt-1 text-3xl font-semibold"><?php echo e($totalProducts); ?></div>
    </div>
    <div class="card p-5">
      <div class="text-slate-500 text-sm">Total Value</div>
      <div class="mt-1 text-3xl font-semibold">Rp <?php echo e(number_format($totalValue,0,',','.')); ?></div>
    </div>
    <div class="card p-5">
      <div class="text-slate-500 text-sm">Average Price</div>
      <div class="mt-1 text-3xl font-semibold">Rp <?php echo e(number_format($avgPrice,0,',','.')); ?></div>
    </div>
  </div>

  
  <div class="grid xl:grid-cols-3 gap-4 mt-6">
    <div class="xl:col-span-2 card p-5 h-[380px] overflow-hidden">
      <div class="font-semibold mb-3">Earnings Overview</div>
      <div class="h-[calc(100%-1.75rem)]">
        <canvas id="lineChart" class="w-full h-full"></canvas>
      </div>
    </div>
    <div class="card p-5 h-[380px] overflow-hidden">
      <div class="font-semibold mb-3">Revenue Sources</div>
      <div class="h-[calc(100%-1.75rem)]">
        <canvas id="pieChart" class="w-full h-full"></canvas>
      </div>
    </div>
  </div>

  <script>
    // LINE
    const lcEl = document.getElementById('lineChart');
    const lc = lcEl.getContext('2d');
    const grad = lc.createLinearGradient(0,0,0,lcEl.clientHeight || 300);
    grad.addColorStop(0, 'rgba(16,185,129,.28)');
    grad.addColorStop(1, 'rgba(16,185,129,0)');

    new Chart(lc, {
      type: 'line',
      data: {
        labels: <?php echo json_encode($months, 15, 512) ?>,
        datasets: [{
          label: 'Sales',
          data: <?php echo json_encode($lineData, 15, 512) ?>,
          borderColor: '#10b981',
          tension: .35,
          borderWidth: 3,
          pointRadius: 3,
          pointHoverRadius: 5,
          fill: true,
          backgroundColor: grad
        }]
      },
      options: {
        maintainAspectRatio:false,
        plugins:{ legend:{display:false} },
        scales:{ x:{ grid:{display:false}}, y:{ grid:{color:'rgba(15,23,42,.06)'}, ticks:{precision:0} } }
      }
    });

    // DOUGHNUT
    new Chart(document.getElementById('pieChart'), {
      type:'doughnut',
      data:{ labels:<?php echo json_encode($pieLabels, 15, 512) ?>, datasets:[{ data:<?php echo json_encode($pieData, 15, 512) ?>, cutout:'65%' }] },
      options:{ maintainAspectRatio:false, plugins:{ legend:{ position:'bottom', labels:{ usePointStyle:true, boxWidth:8 } } } }
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Sertfikasi Web Developer Ardi\assesment-ardi\resources\views/dashboard.blade.php ENDPATH**/ ?>