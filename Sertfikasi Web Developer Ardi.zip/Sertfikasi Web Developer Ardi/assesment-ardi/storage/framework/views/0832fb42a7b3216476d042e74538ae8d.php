
<?php $__env->startSection('title','Edit Produk'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-semibold mb-4">Edit Produk</h1>

  <form action="<?php echo e(route('products.update',$product)); ?>" method="post" enctype="multipart/form-data" class="card p-6">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    
    <div class="mb-5">
      <label class="block text-sm text-slate-600 mb-1">Thumbnail (unggah untuk mengganti)</label>
      <input type="file" name="thumbnail" class="input !py-1 w-full">
      <?php
        $src = $product->thumbnail ? (Str::startsWith($product->thumbnail,'images/') ? asset($product->thumbnail) : asset('storage/'.$product->thumbnail)) : null;
      ?>
      <?php if($src): ?><img src="<?php echo e($src); ?>" class="h-20 w-20 object-cover rounded-xl border mt-3" /><?php endif; ?>
      <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="grid md:grid-cols-2 gap-6">
      <div>
        <label class="block text-sm text-slate-600 mb-1">Kategori</label>
        <input name="category" value="<?php echo e(old('category',$product->category)); ?>" class="input w-full" required>
        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <label class="block text-sm text-slate-600 mb-1">Produk</label>
        <input name="product" value="<?php echo e(old('product',$product->product)); ?>" class="input w-full relative z-10" required autocomplete="off">
        <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="md:col-span-2">
        <label class="block text-sm text-slate-600 mb-1">Harga</label>
        <input name="harga" type="number" value="<?php echo e(old('harga',$product->harga)); ?>" class="input w-full" min="0" required>
        <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>

    <div class="mt-6 flex gap-2">
      <button class="btn-primary">Update</button>
      <a href="<?php echo e(route('products.index')); ?>" class="btn">Batal</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Sertfikasi Web Developer Ardi\assesment-ardi\resources\views/products/edit.blade.php ENDPATH**/ ?>