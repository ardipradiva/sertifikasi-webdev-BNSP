
<?php $__env->startSection('title','Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-semibold mb-4">Tambah Produk</h1>

  
  <form action="<?php echo e(route('products.store')); ?>" method="post" enctype="multipart/form-data" class="card p-6">
    <?php echo csrf_field(); ?>

    
    <div class="mb-5">
      <label class="block text-sm text-slate-600 mb-1">Thumbnail (opsional)</label>
      <input type="file" name="thumbnail" class="input !py-1 w-full">
      <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="grid md:grid-cols-2 gap-6">
      <div>
        <label class="block text-sm text-slate-600 mb-1">Kategori</label>
        <input name="category" value="<?php echo e(old('category')); ?>" class="input w-full" placeholder="Contoh: Samsung" required>
        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div>
        <label class="block text-sm text-slate-600 mb-1">Produk</label>
        
        <input name="product" value="<?php echo e(old('product')); ?>" class="input w-full relative z-10" placeholder="Contoh: Galaxy Z Flip" required autocomplete="off">
        <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="md:col-span-2">
        <label class="block text-sm text-slate-600 mb-1">Harga</label>
        <input name="harga" type="number" value="<?php echo e(old('harga')); ?>" class="input w-full" placeholder="Contoh: 5000000" min="0" required>
        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>

    <div class="mt-6 flex gap-2">
      <button class="btn-primary">Simpan</button>
      <a href="<?php echo e(route('products.index')); ?>" class="btn">Batal</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Sertfikasi Web Developer Ardi\assesment-ardi\resources\views/products/create.blade.php ENDPATH**/ ?>