
<?php $__env->startSection('title','Products'); ?>

<?php $__env->startSection('content'); ?>
  <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
    <h1 class="text-2xl font-semibold">Products</h1>
    <div class="flex gap-2">
      <input id="quickSearch" class="input" placeholder="Cari produk…">
      <a href="<?php echo e(route('products.create')); ?>" class="btn-primary">Tambah Produk</a>
    </div>
  </div>

  <div class="card overflow-x-auto">
    <table id="tbl" class="min-w-full text-sm">
      <thead class="bg-slate-50">
        <tr>
          <th class="px-4 py-3 text-left">Thumbnail</th>
          <th class="px-4 py-3 text-left">Produk</th>
          <th class="px-4 py-3 text-left">Kategori</th>
          <th class="px-4 py-3 text-left">Harga</th>
          <th class="px-4 py-3 text-left">Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t hover:bg-slate-50">
          <td class="px-4 py-3">
            <?php
              $src = $p->thumbnail ? (Str::startsWith($p->thumbnail,'images/') ? asset($p->thumbnail) : asset('storage/'.$p->thumbnail)) : null;
            ?>
            <?php if($src): ?>
              <img src="<?php echo e($src); ?>" class="h-12 w-12 object-cover rounded-xl border"/>
            <?php else: ?>
              <span class="badge">No Image</span>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3 font-medium"><?php echo e($p->product_name); ?></td>
          <td class="px-4 py-3"><?php echo e($p->category); ?></td>
          <td class="px-4 py-3">Rp <?php echo e(number_format($p->price,0,',','.')); ?></td>
          <td class="px-4 py-3">
            <div class="flex gap-2">
              <a class="btn" href="<?php echo e(route('products.edit',$p)); ?>">Edit</a>
              <form action="<?php echo e(route('products.destroy',$p)); ?>" method="post" onsubmit="return confirm('Hapus produk ini?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn">Delete</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td class="px-4 py-6" colspan="5">Belum ada data.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="mt-4"><?php echo e($products->links()); ?></div>

  <script>
    // quick filter
    const q = document.getElementById('quickSearch');
    const rows = () => Array.from(document.querySelectorAll('#tbl tbody tr'));
    q?.addEventListener('input', e => {
      const s = e.target.value.toLowerCase();
      rows().forEach(tr => tr.style.display = tr.innerText.toLowerCase().includes(s) ? '' : 'none');
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Sertfikasi Web Developer Ardi\assesment-ardi\resources\views/products/index.blade.php ENDPATH**/ ?>